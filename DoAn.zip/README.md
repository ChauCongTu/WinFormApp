# BTL LTTQ

Chủ đề: Quản lý cửa hàng xe Honda Phát Tiến

# Team

- Chau Que Nhon
- Vo Van Trong
- Vo Khac Manh
- Bui Nhat Huy
- Nguyen Cao An
- Luu Nhat Thanh
- Le Thanh Nhan

# Hướng dẫn code

- [ ] Trước khi code 1 tinh năng nào đó, anh em tạo một nhánh mới với lệnh `git checkout -b <tên nhánh>`
- [ ] Sau khi code xong `git status` để xem nhung file nào thay đổi
- [ ] `git add .` để thêm tất cả thay đổi
- [ ] `git commit -m <message>`
- [ ] `git push`

**Notes:**

- Nếu đây lần đầu anh em push code lên nhánh này thì nó sẽ hiện bắt anh em dùng lệnh `git push --set-upstream origin feature/report-ui`

Như hình sau: 

![Screenshot 2022-10-30 at 21 42 57](https://user-images.githubusercontent.com/89147472/198884762-4565fc1f-cdd1-4a04-9cd5-a635cb2ef175.png)

- Anh em chỉ việc copy dòng lệnh đó và dán vào terminal enter là xong

